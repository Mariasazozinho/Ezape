const materiais = {
    papel: { pontos: 10 },
    plastico: { pontos: 20 },
    vidro: { pontos: 15 },
    organico: { pontos: 5 }
};

let pontos = 0;
let reciclaveis = [];

function adicionarReciclavel() {
    let materialSelecionado = document.getElementById("material").value;
    let peso = parseFloat(document.getElementById("peso").value);

    if (isNaN(peso) || peso <= 0) {
        alert("Por favor, insira um peso válido.");
        return;
    }

    reciclaveis.push(materialSelecionado);
    pontos += materiais[materialSelecionado].pontos * peso;

    document.getElementById("recompensa").innerText = `Pontos acumulados: ${pontos}`;
}